public interface FlyBehaviour {
    public void fly();
}